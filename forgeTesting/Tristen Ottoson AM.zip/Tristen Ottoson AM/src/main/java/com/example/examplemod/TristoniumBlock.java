package com.example.examplemod;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class TristoniumBlock extends Block {

	public TristoniumBlock(Material p_i45394_1_) {
		super(p_i45394_1_);
		// TODO Auto-generated constructor stub
	}

}
