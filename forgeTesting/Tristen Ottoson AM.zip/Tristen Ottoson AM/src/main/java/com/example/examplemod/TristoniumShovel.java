package com.example.examplemod;

import net.minecraft.item.ItemSpade;

public class TristoniumShovel extends ItemSpade {

	public TristoniumShovel(ToolMaterial p_i45353_1_) {
		super(p_i45353_1_);
		// TODO Auto-generated constructor stub
	}

}
