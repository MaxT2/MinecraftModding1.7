package com.example.examplemod;

import net.minecraft.item.ItemPickaxe;

public class TristoniumPickaxe extends ItemPickaxe {

	public TristoniumPickaxe(ToolMaterial p_i45347_1_) {
		super(p_i45347_1_);
		// TODO Auto-generated constructor stub
	}

}
