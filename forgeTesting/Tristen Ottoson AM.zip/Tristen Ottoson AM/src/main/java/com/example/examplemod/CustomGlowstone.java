package com.example.examplemod;

import net.minecraft.block.BlockGlowstone;
import net.minecraft.block.material.Material;

public class CustomGlowstone extends BlockGlowstone {

	public CustomGlowstone(Material p_i45409_1_) {
		super(p_i45409_1_);
		// TODO Auto-generated constructor stub
	}

}
