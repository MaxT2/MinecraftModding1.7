package com.example.examplemod;

import net.minecraft.item.Item;

public class GenericItem extends Item {

	public GenericItem() {
		// TODO Auto-generated constructor stub
	}

}
