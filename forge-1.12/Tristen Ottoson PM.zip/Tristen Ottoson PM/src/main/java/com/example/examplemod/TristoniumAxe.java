package com.example.examplemod;

import net.minecraft.item.ItemAxe;

public class TristoniumAxe extends ItemAxe {

	public TristoniumAxe(ToolMaterial p_i45327_1_) {
		super(p_i45327_1_);
		// TODO Auto-generated constructor stub
	}

}
