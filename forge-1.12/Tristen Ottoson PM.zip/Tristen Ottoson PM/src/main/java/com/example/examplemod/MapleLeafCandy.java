package com.example.examplemod;

import net.minecraft.item.ItemFood;

public class MapleLeafCandy extends ItemFood {

	public MapleLeafCandy(int p_i45340_1_, boolean p_i45340_2_) {
		super(p_i45340_1_, p_i45340_2_);
		// TODO Auto-generated constructor stub
	}

	public MapleLeafCandy(int p_i45339_1_, float p_i45339_2_, boolean p_i45339_3_) {
		super(p_i45339_1_, p_i45339_2_, p_i45339_3_);
		// TODO Auto-generated constructor stub
	}

}
