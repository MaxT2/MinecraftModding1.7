/**
 * 
 */
/**
 * @author Tristen
 *
 */
package assets.examplemod.textures.items;