/**
 * 
 */
/**
 * @author Tristen
 *
 */
package assets.examplemod.lang;